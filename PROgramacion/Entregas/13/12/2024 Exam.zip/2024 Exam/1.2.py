age=int(input('How old are you?: ')) #ask and save the age of the user

if age>= 18: #control flow to see if the user is either underaged or not
    print('You can come in!')

else:
    print('You shall not pass')