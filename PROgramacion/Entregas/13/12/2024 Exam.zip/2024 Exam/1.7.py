list= [0,1,2,3,4,5,6,7,8,9,10] #a list of numbers
for i in list: #iteration to search numers below 5
    if i<5:
        print(i)

    else:
        continue